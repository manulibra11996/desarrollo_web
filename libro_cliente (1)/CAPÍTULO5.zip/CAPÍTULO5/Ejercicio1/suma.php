<?php
   $valor1 = $_POST['valor1'];
   $valor2  = $_POST['valor2'];
   $suma = $valor1+$valor2;
   echo "La suma es: ".$suma;
?>
