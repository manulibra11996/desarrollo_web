<?php
   $valor1 = $_GET['valor1'];
   $valor2  = $_GET['valor2'];
   $suma = $valor1+$valor2;
   echo "La suma es: ".$suma;
?>
