function verdadero(p){
   document.getElementById(p).style.color = "green";
}

function falso(p) {
   document.getElementById(p).style.color = "red";
}
