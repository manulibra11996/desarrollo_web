function saluda(msg){
   var texto = document.getElementById('texto');
   texto.innerHTML = msg;
}
