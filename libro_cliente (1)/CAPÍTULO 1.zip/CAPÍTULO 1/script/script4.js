
function saluda() {
   console.log("Hola SÍNTESIS");
}
