function diAlgo()
{
   alert("hola");
}
diAlgo();
